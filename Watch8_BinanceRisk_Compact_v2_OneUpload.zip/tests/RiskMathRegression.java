import com.httools.wearrisk.RiskMath;

public class RiskMathRegression {
    private static int count = 0;
    private static void check(boolean ok, String msg) {
        if (!ok) throw new AssertionError(msg);
        count++;
    }
    private static void run(int side, double target) {
        RiskMath.Result r = RiskMath.compute(100, 1000, side, target,
                0.05, 0.05, 0, 0.01);
        check(r.price > 0, "positive trigger price");
        check(r.netPnl >= target - 0.0000001, "net PnL must meet requested target");
        check(r.priceOnCorrectSide, "price must be on the right side");
        check(Math.abs(r.qty - 10) < 1e-9, "contract qty");
        check(Math.abs(r.totalFee - (0.5 + r.price * 10 * 0.0005)) < 1e-8,
                "fees must match original formula");
        check(Math.abs(r.price * 100 - Math.rint(r.price * 100)) < 1e-8,
                "price rounded to the tick");
        if (side == RiskMath.LONG) {
            check(target < 0 ? r.price < 100 : r.price > 100, "long direction");
        } else {
            check(target < 0 ? r.price > 100 : r.price < 100, "short direction");
        }
    }
    public static void main(String[] args) {
        run(RiskMath.LONG, -10);
        run(RiskMath.LONG, 10);
        run(RiskMath.SHORT, -10);
        run(RiskMath.SHORT, 10);
        check(Math.abs(RiskMath.number("1,234.56") - 1234.56) < 1e-8, "US thousands");
        check(Math.abs(RiskMath.number("1,25") - 1.25) < 1e-8, "decimal comma");
        check(Double.isNaN(RiskMath.number("not a number")), "invalid input");
        RiskMath.Result extra = RiskMath.compute(100, 1000, RiskMath.LONG,
                10, 0.05, 0.05, 2, 0.01);
        check(extra.netPnl >= 10 - 1e-8, "extra cost included");
        boolean rejected = false;
        try { RiskMath.compute(100, 1000, RiskMath.LONG, 10, 0.05, 100, 0, 0.01); }
        catch (IllegalArgumentException ex) { rejected = true; }
        check(rejected, "invalid fees rejected");
        System.out.println("PASS " + count + " risk math assertions");
    }
}
