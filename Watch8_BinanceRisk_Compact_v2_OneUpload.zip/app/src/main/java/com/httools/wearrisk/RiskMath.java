package com.httools.wearrisk;

import java.math.BigDecimal;
import java.math.RoundingMode;

/** USDⓈ-M linear contract estimates, using the actual notional at entry.
 * Gross PnL = side * qty * (exit-entry).
 * Entry fee = entry * qty * entryRate; exit fee = exit * qty * exitRate.
 * Extra buffer is an estimated additive funding/slippage cost, not a guaranteed charge.
 */
public final class RiskMath {
    private RiskMath() {}
    public static final int LONG = 1, SHORT = -1;
    public static final class Result {
        public final double rawPrice, price, notional, qty, openingFee, closingFee,
                grossPnl, netPnl, targetNet, deltaPct, totalFee;
        public final boolean priceOnCorrectSide;
        Result(double rawPrice, double price, double notional, double qty,
               double openingFee, double closingFee, double grossPnl, double netPnl,
               double targetNet, double deltaPct, boolean priceOnCorrectSide) {
            this.rawPrice=rawPrice; this.price=price; this.notional=notional; this.qty=qty;
            this.openingFee=openingFee; this.closingFee=closingFee;
            this.grossPnl=grossPnl; this.netPnl=netPnl; this.targetNet=targetNet;
            this.deltaPct=deltaPct; this.totalFee=openingFee+closingFee;
            this.priceOnCorrectSide=priceOnCorrectSide;
        }
    }
    public static Result compute(double entry, double notional, int side, double targetNet,
                                 double feeOpenPct, double feeClosePct,
                                 double extraCost, double tick) {
        if (!(entry > 0) || !(notional > 0) || !(tick > 0)
                || (side != LONG && side != SHORT) || feeOpenPct < 0 || feeClosePct < 0
                || feeOpenPct >= 100 || feeClosePct >= 100 || extraCost < 0
                || !Double.isFinite(entry) || !Double.isFinite(notional)
                || !Double.isFinite(targetNet) || !Double.isFinite(tick)
                || !Double.isFinite(extraCost) || !Double.isFinite(feeOpenPct)
                || !Double.isFinite(feeClosePct)) {
            throw new IllegalArgumentException("请检查开仓价、仓位、费率和价格步长");
        }
        double fO = feeOpenPct/100d, fC = feeClosePct/100d;
        double qty=notional/entry;
        double denominator=side-fC;
        if (Math.abs(denominator) < 1e-9) throw new IllegalArgumentException("平仓手续费率无效");
        double raw=entry * (side+fO+(targetNet+extraCost)/notional)/denominator;
        if (!(raw>0) || !Double.isFinite(raw))
            throw new IllegalArgumentException("当前目标需要非正数价格，无法实现");
        // Long: round up, Short: round down. This keeps the estimated PnL on the
        // safer side of the requested net target, for the assumed fill price.
        BigDecimal step=BigDecimal.valueOf(tick);
        BigDecimal units=BigDecimal.valueOf(raw).divide(step, 0,
                side==LONG ? RoundingMode.CEILING : RoundingMode.FLOOR);
        double p=units.multiply(step).doubleValue();
        if (!(p>0)) throw new IllegalArgumentException("价格小于允许精度，无法设置");
        double opFee=notional*fO;
        double clFee=qty*p*fC;
        double gross=side*qty*(p-entry);
        double net=gross-opFee-clFee-extraCost;
        boolean correct=targetNet<0 ? (side==LONG ? p<entry : p>entry)
                : (side==LONG ? p>entry : p<entry);
        return new Result(raw, p, notional, qty, opFee, clFee, gross, net,
                targetNet,(p/entry-1)*100,correct);
    }
    public static double number(String s) {
        if (s==null) return Double.NaN;
        s=s.trim().replace(" ","").replace("$","").replace("％","").replace("%","");
        if (s.isEmpty()) return Double.NaN;
        // Chinese/US decimals and decimal-comma supported. A price is normally
        // pasted with '.'; do not interpret thousands separators as decimals.
        if (s.indexOf(',')>=0 && s.indexOf('.')>=0) s=s.replace(",","");
        else if (s.indexOf(',')>=0) {
            if (s.matches("[-+]?\\d{1,3}(,\\d{3})+")) s=s.replace(",", "");
            else s=s.replace(',', '.');
        }
        try { return Double.parseDouble(s); } catch(Exception e) { return Double.NaN; }
    }
}
