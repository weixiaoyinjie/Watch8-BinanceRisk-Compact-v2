package com.httools.wearrisk;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.Locale;

/**
 * Offline Wear OS port of BinanceRiskFloating v1.2.
 * It calculates risk trigger prices; it cannot connect to Binance or place orders.
 * Uses an in-app 0-9 decimal keypad instead of the system keyboard.
 */
public final class MainActivity extends Activity {
    private static final int BLACK = 0xff000000;
    private static final int PANEL = 0xff11191b;
    private static final int EDGE = 0xff2e4545;
    private static final int MINT = 0xff2bd5bb;
    private static final int WHITE = 0xffeef7f5;
    private static final int MUTED = 0xffb1c0be;
    private static final int WARNING = 0xffffc477;
    private static final int BAD = 0xffff9296;
    private final DecimalFormat money = new DecimalFormat("#,##0.00",
            DecimalFormatSymbols.getInstance(Locale.US));

    private SharedPreferences prefs;
    private int mode = 0;  // 0=stop-loss, 1=take-profit
    private int side = RiskMath.LONG;
    private boolean advanced = false;
    private boolean editing = false;
    private String editKey;
    private String editValue;
    private String editTitle;
    private TextView editPreview;
    private int savedScroll = 0;
    private ScrollView mainScroll;
    private String validPrice;
    private int safeInset;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        prefs = getSharedPreferences("risk_settings", MODE_PRIVATE);
        mode = prefs.getInt("mode", 0) == 1 ? 1 : 0;
        side = prefs.getInt("side", RiskMath.LONG) == RiskMath.SHORT
                ? RiskMath.SHORT : RiskMath.LONG;
        int widthDp = Math.round(getResources().getDisplayMetrics().widthPixels /
                getResources().getDisplayMetrics().density);
        safeInset = Math.max(18, Math.min(38, Math.round(widthDp * .105f)));
        buildMain();
    }

    private int dp(float value) {
        return (int) (getResources().getDisplayMetrics().density * value + .5f);
    }

    private LinearLayout column() {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        return layout;
    }

    private LinearLayout row() {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.HORIZONTAL);
        layout.setGravity(Gravity.CENTER_VERTICAL);
        return layout;
    }

    private GradientDrawable background(int fill, int border, int radius) {
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(fill);
        bg.setCornerRadius(dp(radius));
        if (border != 0) bg.setStroke(dp(1), border);
        return bg;
    }

    private TextView text(String value, int sizeSp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sizeSp);
        t.setTextColor(color);
        t.setIncludeFontPadding(false);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private void autoFit(TextView label, int minSp, int maxSp) {
        label.setAutoSizeTextTypeUniformWithConfiguration(minSp, maxSp, 1,
                TypedValue.COMPLEX_UNIT_SP);
    }

    private LinearLayout.LayoutParams sized(int height, int top) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, height < 0 ? height : dp(height));
        lp.topMargin = dp(top);
        return lp;
    }

    /**
     * Full first screen: the four choices, four primary inputs and trigger price.
     * All calculations, diagnostics and preferences stay available by scrolling down.
     * Heights are sized from the actual device height (dp) rather than a fixed phone size.
     */
    private void buildMain() {
        editing = false;
        validPrice = null;
        int screenHeightPx = getResources().getDisplayMetrics().heightPixels;
        int screenHeightDp = Math.round(screenHeightPx /
                getResources().getDisplayMetrics().density);
        int headerH = Math.max(13, Math.min(17, Math.round(screenHeightDp * .073f)));
        int switchH = Math.max(20, Math.min(27, Math.round(screenHeightDp * .108f)));
        int fieldH = Math.max(28, Math.min(40, Math.round(screenHeightDp * .16f)));
        int priceH = Math.max(25, Math.min(36, Math.round(screenHeightDp * .135f)));
        int pageTop = Math.max(6, Math.min(9, Math.round(screenHeightDp * .035f)));
        int hintH = screenHeightDp < 200 ? 9 : 10;
        int resultTitleH = screenHeightDp < 200 ? 10 : 11;
        // Keep primary controls within one actual circular-display viewport.
        int usedDp = pageTop + headerH + 2 + switchH + 2 + switchH + 3
                + fieldH + 3 + fieldH + 3 + resultTitleH + 2 + priceH
                + 2 + hintH + 2;
        while (usedDp > screenHeightDp && fieldH > 26) {
            fieldH--;
            usedDp -= 2;
        }

        mainScroll = new ScrollView(this);
        mainScroll.setFillViewport(false);
        mainScroll.setBackgroundColor(BLACK);
        mainScroll.setVerticalScrollBarEnabled(false);
        LinearLayout content = column();
        mainScroll.addView(content, new ScrollView.LayoutParams(-1, -2));

        LinearLayout firstPage = column();
        firstPage.setPadding(dp(safeInset), dp(pageTop), dp(safeInset), dp(2));
        // The second page begins below precisely one full watch-screen height.
        content.addView(firstPage, new LinearLayout.LayoutParams(-1, screenHeightPx));
        TextView header = text("合约止盈 / 止损", screenHeightDp < 200 ? 13 : 14, WHITE, true);
        header.setGravity(Gravity.CENTER);
        header.setSingleLine(true);
        firstPage.addView(header, sized(headerH, 0));

        LinearLayout modeBar = row();
        modeBar.addView(segment(mode == 0 ? "止损 ✓" : "止损", mode == 0,
                () -> switchMode(0)), weighted(switchH, 1, 0));
        modeBar.addView(segment(mode == 1 ? "止盈 ✓" : "止盈", mode == 1,
                () -> switchMode(1)), weighted(switchH, 1, 4));
        modeBar.setPadding(dp(7), 0, dp(7), 0);
        firstPage.addView(modeBar, sized(switchH, 2));
        LinearLayout sideBar = row();
        sideBar.addView(segment(side == RiskMath.LONG ? "做多 ✓" : "做多",
                side == RiskMath.LONG, () -> switchSide(RiskMath.LONG)),
                weighted(switchH, 1, 0));
        sideBar.addView(segment(side == RiskMath.SHORT ? "做空 ✓" : "做空",
                side == RiskMath.SHORT, () -> switchSide(RiskMath.SHORT)),
                weighted(switchH, 1, 4));
        firstPage.addView(sideBar, sized(switchH, 2));

        LinearLayout pair1 = row();
        pair1.addView(compactField("实际开仓价", "entry", "输入价格", fieldH),
                weighted(fieldH, 1, 0));
        pair1.addView(compactField("杠杆 ×", "leverage", "50", fieldH),
                weighted(fieldH, 1, 4));
        firstPage.addView(pair1, sized(fieldH, 3));
        LinearLayout pair2 = row();
        pair2.addView(compactField("保证金 USDT", "margin", "100", fieldH),
                weighted(fieldH, 1, 0));
        pair2.addView(compactField(mode == 0 ? "净亏损 USDT" : "净盈利 USDT",
                mode == 0 ? "loss0" : "profit0", "10", fieldH),
                weighted(fieldH, 1, 4));
        firstPage.addView(pair2, sized(fieldH, 3));

        TextView resultTitle = text(mode == 0 ? "止损触发价" : "止盈触发价",
                10, MUTED, true);
        resultTitle.setGravity(Gravity.CENTER);
        firstPage.addView(resultTitle, sized(resultTitleH, 3));
        TextView price = text("—", 23, MINT, true);
        price.setGravity(Gravity.CENTER);
        price.setPadding(dp(4), 0, dp(4), 0);
        price.setBackground(background(PANEL, EDGE, 10));
        price.setSingleLine(true);
        autoFit(price, 10, 23);
        firstPage.addView(price, sized(priceH, 2));
        TextView copyPrompt = text("点价复制 · 下滑设置", 9, MUTED, false);
        copyPrompt.setGravity(Gravity.CENTER);
        copyPrompt.setSingleLine(true);
        autoFit(copyPrompt, 8, 10);
        firstPage.addView(copyPrompt, sized(hintH, 2));

        // Settings, full risk diagnostics and the explanatory text are below the first screen.
        LinearLayout secondPage = column();
        secondPage.setPadding(dp(safeInset), dp(9), dp(safeInset), dp(32));
        content.addView(secondPage, new LinearLayout.LayoutParams(-1, -2));
        TextView sectionHeader = text("设置 / 详细结果", 15, WHITE, true);
        sectionHeader.setGravity(Gravity.CENTER);
        secondPage.addView(sectionHeader, sized(24, 0));
        TextView settings = text(advanced ? "▾  收起高级参数" : "▸  高级参数 / 手续费",
                13, WHITE, true);
        settings.setGravity(Gravity.CENTER_VERTICAL);
        settings.setPadding(dp(12), 0, dp(7), 0);
        settings.setBackground(background(PANEL, EDGE, 10));
        settings.setOnClickListener(v -> {
            savedScroll = mainScroll.getScrollY();
            advanced = !advanced;
            buildMain();
        });
        secondPage.addView(settings, sized(39, 9));
        if (advanced) {
            secondPage.addView(fieldCard("实际仓位 USDT（选填）", "notional", "留空则按杠杆计算"), sized(-2, 7));
            LinearLayout fees = row();
            fees.addView(fieldCard("开仓费率 %", "feeOpen", "0.05"), weighted(-2, 1, 0));
            fees.addView(fieldCard("平仓费率 %", "feeClose", "0.05"), weighted(-2, 1, 6));
            secondPage.addView(fees, sized(-2, 6));
            secondPage.addView(fieldCard("最小价格步长", "tick", "0.00001"), sized(-2, 6));
            secondPage.addView(fieldCard("额外成本 USDT", "extra", "0"), sized(-2, 6));
        }
        TextView detailsTitle = text("计算明细", 12, MUTED, true);
        secondPage.addView(detailsTitle, sized(-2, 14));
        TextView notionalInfo = text("", 12, MINT, false);
        secondPage.addView(notionalInfo, sized(-2, 8));
        TextView pnlInfo = text("", 12, WHITE, false);
        pnlInfo.setLineSpacing(dp(4), 1f);
        secondPage.addView(pnlInfo, sized(-2, 8));
        TextView warning = text("", 11, WARNING, false);
        warning.setLineSpacing(dp(3), 1f);
        secondPage.addView(warning, sized(-2, 8));
        TextView foot = text("离线估算 · 不会实际下单\n仅限 USDT 本位线性合约。手续费默认开平各 0.05%。\n"
                + "需自行核对交易对价格步长。实际滑点、资金费和强平可能改变盈亏。",
                10, MUTED, false);
        foot.setGravity(Gravity.CENTER);
        foot.setLineSpacing(dp(3), 1f);
        secondPage.addView(foot, sized(-2, 15));

        refresh(price, copyPrompt, notionalInfo, pnlInfo, warning);
        price.setOnClickListener(v -> {
            if (validPrice == null) {
                Toast.makeText(this, "当前价格不适合复制，请检查参数", Toast.LENGTH_SHORT).show();
            } else {
                copyPrice(validPrice);
            }
        });
        setContentView(mainScroll);
        mainScroll.post(() -> mainScroll.scrollTo(0, savedScroll));
    }

    /** A compact two-line input that still opens the exact original input editor. */
    private LinearLayout compactField(String label, String key, String placeholder, int height) {
        LinearLayout card = column();
        card.setBackground(background(PANEL, EDGE, 9));
        TextView heading = text(label, 10, MUTED, false);
        heading.setGravity(Gravity.CENTER_VERTICAL);
        heading.setSingleLine(true);
        heading.setPadding(dp(6), 0, dp(4), 0);
        autoFit(heading, 8, 10);
        card.addView(heading, sized(12, 0));
        String val = prefs.getString(key, defaultFor(key));
        TextView number = text(val.isEmpty() ? placeholder : val, 16,
                val.isEmpty() ? MUTED : MINT, true);
        number.setGravity(Gravity.CENTER_VERTICAL | Gravity.LEFT);
        number.setSingleLine(true);
        number.setPadding(dp(6), 0, dp(4), 0);
        autoFit(number, 9, 16);
        card.addView(number, sized(height - 12, 0));
        card.setContentDescription(label + " " + (val.isEmpty() ? "未输入" : val));
        card.setOnClickListener(v -> {
            if (mainScroll != null) savedScroll = mainScroll.getScrollY();
            openKeypad(key, label, val);
        });
        return card;
    }

    private LinearLayout.LayoutParams weighted(int height, int weight, int left) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0,
                height < 0 ? height : dp(height), weight);
        lp.leftMargin = dp(left);
        return lp;
    }

    private TextView segment(String title, boolean selected, Runnable action) {
        TextView btn = text(title, 12, selected ? BLACK : WHITE, true);
        btn.setGravity(Gravity.CENTER);
        btn.setSingleLine(true);
        autoFit(btn, 9, 12);
        btn.setBackground(background(selected ? MINT : PANEL, selected ? 0 : EDGE, 12));
        btn.setOnClickListener(v -> action.run());
        return btn;
    }

    private LinearLayout fieldCard(String label, String key, String placeholder) {
        LinearLayout card = column();
        card.setBackground(background(PANEL, EDGE, 11));
        card.setPadding(dp(10), dp(8), dp(10), dp(9));
        TextView heading = text(label, 11, MUTED, false);
        heading.setSingleLine(true);
        autoFit(heading, 9, 11);
        card.addView(heading, sized(17, 0));
        String val = prefs.getString(key, defaultFor(key));
        TextView number = text(val.isEmpty() ? placeholder : val, 19,
                val.isEmpty() ? MUTED : MINT, true);
        number.setSingleLine(true);
        number.setGravity(Gravity.CENTER_VERTICAL | Gravity.LEFT);
        autoFit(number, 10, 19);
        card.addView(number, sized(24, 3));
        card.setContentDescription(label + " " + (val.isEmpty() ? "未输入" : val));
        card.setOnClickListener(v -> {
            if (mainScroll != null) savedScroll = mainScroll.getScrollY();
            openKeypad(key, label, val);
        });
        return card;
    }

    private String defaultFor(String key) {
        switch (key) {
            case "leverage": return "50";
            case "margin": return "100";
            case "loss0":
            case "profit0": return "10";
            case "feeOpen":
            case "feeClose": return "0.05";
            case "tick": return "0.00001";
            case "extra": return "0";
            default: return "";
        }
    }

    private void switchMode(int chosen) {
        if (chosen == mode) return;
        mode = chosen;
        prefs.edit().putInt("mode", mode).apply();
        savedScroll = mainScroll == null ? 0 : mainScroll.getScrollY();
        buildMain();
    }

    private void switchSide(int chosen) {
        if (chosen == side) return;
        side = chosen;
        prefs.edit().putInt("side", side).apply();
        savedScroll = mainScroll == null ? 0 : mainScroll.getScrollY();
        buildMain();
    }

    private void refresh(TextView price, TextView copyPrompt, TextView notion,
                         TextView pnl, TextView warn) {
        String entryText = prefs.getString("entry", "");
        double entry = RiskMath.number(entryText);
        double leverage = RiskMath.number(prefs.getString("leverage", "50"));
        double margin = RiskMath.number(prefs.getString("margin", "100"));
        String override = prefs.getString("notional", "").trim();
        double notional = override.isEmpty() ? leverage * margin : RiskMath.number(override);
        double openFee = RiskMath.number(prefs.getString("feeOpen", "0.05"));
        double closeFee = RiskMath.number(prefs.getString("feeClose", "0.05"));
        double tick = RiskMath.number(prefs.getString("tick", "0.00001"));
        double extra = RiskMath.number(prefs.getString("extra", "0"));
        double target = RiskMath.number(prefs.getString(mode == 0 ? "loss0" : "profit0", "10"));
        if (!(entry > 0) || !(leverage > 0) || !(margin > 0) || !(notional > 0)
                || !(tick > 0) || !Double.isFinite(entry) || !Double.isFinite(leverage)
                || !Double.isFinite(margin) || !Double.isFinite(notional)
                || !Double.isFinite(openFee) || !Double.isFinite(closeFee)
                || !Double.isFinite(tick) || !Double.isFinite(extra)
                || openFee < 0 || closeFee < 0 || extra < 0) {
            price.setText("—");
            copyPrompt.setText("输入有效参数后显示价格");
            notion.setText("仓位金额：—");
            pnl.setText("");
            warn.setText("请检查开仓价、杠杆、保证金和价格步长");
            return;
        }
        notion.setText("保证金 " + number(margin, 2) + " U × " + number(leverage, 2)
                + " 倍\n仓位 " + cash(notional));
        if (!(target > 0) || !Double.isFinite(target)) {
            price.setText("—");
            copyPrompt.setText("请输入大于 0 的目标金额");
            warn.setText("目标净" + (mode == 0 ? "亏损" : "盈利") + "金额应大于 0");
            return;
        }
        try {
            RiskMath.Result result = RiskMath.compute(entry, notional, side,
                    mode == 0 ? -target : target, openFee, closeFee, extra, tick);
            String formatted = priceText(result.price, tick);
            boolean allowed = result.priceOnCorrectSide && !(mode == 0 && target >= margin);
            price.setText(formatted);
            price.setTextColor(allowed ? MINT : WARNING);
            validPrice = allowed ? formatted : null;
            copyPrompt.setText(allowed ? "点价复制 · 下滑设置" : "⚠ 方向不合适 · 下滑查看");
            pnl.setText("预计净" + (mode == 0 ? "亏损" : "盈利") + "  "
                    + cash(Math.abs(result.netPnl))
                    + "\n预计剩余保证金  " + cash(margin + result.netPnl)
                    + "\n预计开平手续费  " + cash(result.totalFee)
                    + "\n开 / 平费率  " + number(openFee, 4) + "% / "
                    + number(closeFee, 4) + "%"
                    + (extra > 0 ? "\n额外成本  " + cash(extra) : ""));
            if (mode == 0 && target >= margin) {
                warn.setText("⚠ 目标亏损达到或超过保证金，强平可能先触发，请降低目标金额。");
            } else if (!result.priceOnCorrectSide) {
                warn.setText("⚠ 扣除费用后的触发价位于不合适的一侧，不能作为正常"
                        + (mode == 0 ? "止损" : "止盈") + "单。");
            } else {
                warn.setText("按触发价成交的估算。滑点、资金费及强平可能造成不同结果。");
            }
        } catch (IllegalArgumentException ex) {
            price.setText(ex.getMessage());
            price.setTextColor(BAD);
            copyPrompt.setText("当前参数无法计算");
            pnl.setText("");
            warn.setText("请核对交易对价格精度、杠杆及手续费。");
        }
    }

    private void openKeypad(String key, String title, String current) {
        editKey = key;
        editTitle = title;
        editValue = current;
        editing = true;
        buildKeypad();
    }

    /** Complete numerical input screen without an additional swipe on Watch8. */
    private void buildKeypad() {
        int heightDp = Math.round(getResources().getDisplayMetrics().heightPixels /
                getResources().getDisplayMetrics().density);
        int widthDp = Math.round(getResources().getDisplayMetrics().widthPixels /
                getResources().getDisplayMetrics().density);
        int top = Math.max(10, Math.min(16, Math.round(heightDp * .077f)));
        int headerH = heightDp < 200 ? 16 : 18;
        int previewH = heightDp < 200 ? 25 : 28;
        int doneH = heightDp < 200 ? 24 : 26;
        int bottom = Math.max(8, Math.round(heightDp * .05f));
        int fixedDp = top + headerH + 2 + previewH + 2 + 4 * 2 + 4 + doneH + bottom;
        int keyHeight = Math.max(19, Math.min(40, (heightDp - fixedDp) / 4));

        LinearLayout root = column();
        root.setGravity(Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        root.setBackgroundColor(BLACK);
        root.setPadding(dp(safeInset), dp(top), dp(safeInset), dp(bottom));
        LinearLayout heading = row();
        int headerExtraInset = Math.max(14, Math.round(widthDp * .10f));
        heading.setPadding(dp(headerExtraInset), 0, dp(headerExtraInset), 0);
        TextView cancel = text("‹ 返回", 10, MUTED, true);
        cancel.setGravity(Gravity.CENTER_VERTICAL);
        cancel.setOnClickListener(v -> cancelEdit());
        heading.addView(cancel, weighted(headerH, 1, 0));
        TextView title = text(editTitle, 11, WHITE, true);
        title.setGravity(Gravity.CENTER);
        title.setSingleLine(true);
        autoFit(title, 8, 11);
        heading.addView(title, weighted(headerH, 2, 0));
        TextView paste = text("粘贴", 10, MINT, true);
        paste.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        paste.setOnClickListener(v -> pasteNumber());
        heading.addView(paste, weighted(headerH, 1, 0));
        root.addView(heading, sized(headerH, 0));

        editPreview = text("", 22, MINT, true);
        editPreview.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        editPreview.setSingleLine(true);
        autoFit(editPreview, 9, 22);
        editPreview.setPadding(dp(8), 0, dp(8), 0);
        editPreview.setBackground(background(PANEL, EDGE, 9));
        root.addView(editPreview, sized(previewH, 2));
        updatePreview();

        String[][] digits = {{"1", "2", "3"}, {"4", "5", "6"},
                {"7", "8", "9"}, {".", "0", "⌫"}};
        for (int i = 0; i < digits.length; i++) {
            LinearLayout digitRow = row();
            for (int j = 0; j < 3; j++) {
                final String digit = digits[i][j];
                TextView btn = text(digit, keyHeight < 23 ? 17 : 20,
                        digit.equals("⌫") ? WARNING : WHITE, true);
                btn.setGravity(Gravity.CENTER);
                btn.setBackground(background(PANEL, EDGE, 8));
                btn.setContentDescription(digit.equals("⌫") ? "删除一个数字" :
                        digit.equals(".") ? "小数点" : "数字" + digit);
                btn.setOnClickListener(v -> pressDigit(digit));
                digitRow.addView(btn, weighted(keyHeight, 1, j == 0 ? 0 : 3));
            }
            root.addView(digitRow, sized(keyHeight, i == 0 ? 2 : 2));
        }
        LinearLayout buttons = row();
        // The last row sits low on a round display: narrow it to avoid clipped corners.
        int bottomExtraInset = Math.max(18, Math.round(widthDp * .14f));
        buttons.setPadding(dp(bottomExtraInset), 0, dp(bottomExtraInset), 0);
        TextView clear = text("清空", 12, WARNING, true);
        clear.setGravity(Gravity.CENTER);
        clear.setBackground(background(PANEL, EDGE, 8));
        clear.setOnClickListener(v -> { editValue = ""; updatePreview(); });
        buttons.addView(clear, weighted(doneH, 1, 0));
        TextView done = text("✓ 完成", 12, BLACK, true);
        done.setGravity(Gravity.CENTER);
        done.setBackground(background(MINT, 0, 8));
        done.setOnClickListener(v -> saveNumber());
        buttons.addView(done, weighted(doneH, 1, 4));
        root.addView(buttons, sized(doneH, 4));
        setContentView(root);
    }

    private void pressDigit(String digit) {
        if (digit.equals("⌫")) {
            if (!editValue.isEmpty()) editValue = editValue.substring(0, editValue.length() - 1);
        } else if (digit.equals(".")) {
            if (editValue.contains(".") || editValue.contains(",")) return;
            editValue = editValue.isEmpty() ? "0." : editValue + ".";
        } else if (editValue.length() < 48) {
            editValue = editValue.equals("0") ? digit : editValue + digit;
        }
        updatePreview();
    }

    private void updatePreview() {
        if (editPreview != null) {
            editPreview.setText(editValue.isEmpty() ? "0" : editValue);
            editPreview.setTextColor(editValue.isEmpty() ? MUTED : MINT);
        }
    }

    private void pasteNumber() {
        ClipboardManager manager = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (manager == null || !manager.hasPrimaryClip()) {
            Toast.makeText(this, "剪贴板无内容", Toast.LENGTH_SHORT).show();
            return;
        }
        ClipData data = manager.getPrimaryClip();
        if (data == null || data.getItemCount() == 0) return;
        CharSequence value = data.getItemAt(0).coerceToText(this);
        if (value == null) return;
        editValue = value.toString().trim();
        updatePreview();
    }

    private void saveNumber() {
        // Preserve original blank 'notional' meaning use margin times leverage.
        prefs.edit().putString(editKey, editValue).apply();
        editing = false;
        editPreview = null;
        buildMain();
    }

    private void cancelEdit() {
        editing = false;
        editPreview = null;
        buildMain();
    }

    private void copyPrice(String value) {
        ClipboardManager manager = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (manager == null || TextUtils.isEmpty(value)) return;
        manager.setPrimaryClip(ClipData.newPlainText("合约触发价", value));
        Toast.makeText(this, "已复制价格：" + value, Toast.LENGTH_SHORT).show();
    }

    private String priceText(double value, double step) {
        int digits = Math.max(0, Math.min(12,
                BigDecimal.valueOf(step).stripTrailingZeros().scale()));
        return BigDecimal.valueOf(value).setScale(digits, RoundingMode.HALF_UP).toPlainString();
    }

    private String number(double value, int digits) {
        if (!Double.isFinite(value)) return "—";
        return BigDecimal.valueOf(value).setScale(digits, RoundingMode.HALF_UP)
                .stripTrailingZeros().toPlainString();
    }

    private String cash(double value) {
        return (value < 0 ? "-" : "") + money.format(Math.abs(value)) + " USDT";
    }

    @Override public void onBackPressed() {
        if (editing) cancelEdit();
        else if (advanced) {
            advanced = false;
            buildMain();
        } else super.onBackPressed();
    }
}
