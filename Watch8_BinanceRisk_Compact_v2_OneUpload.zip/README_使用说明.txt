Watch8 合约止盈止损换算器 v2 — 紧凑圆屏版

本次只更改手表端界面；计算核心 RiskMath.java 与旧版完全一致。
应用 ID 保持 com.httools.wearrisk，版本号升级为 2，可与旧手机版并存。

第一屏：
- 顶部保留止损 / 止盈、做多 / 做空：共 4 个选项。
- 中部两行两列展示 4 个可点击输入框：实际开仓价、杠杆、保证金、净亏损/净盈利目标。
- 底部显示止损或止盈触发价，合法价格可点击复制。
- 尺寸根据手表实际屏幕高度调整，圆屏顶部按钮略缩进。

向下滑到第二屏（及以下）：
- 高级参数：选填仓位、开仓费率、平仓费率、价格步长、额外成本。
- 计算明细：仓位、盈亏、剩余保证金、手续费、风险提示。
- 合约限制与说明文字。
- 所有原有字段的存储键名、默认值及算法不变。

数字输入：
- 单独一屏内包含返回、当前编辑字段、粘贴、数值预览、0~9、小数点、退格、清空、完成。
- 按圆屏实际高度自动缩放数字键，底部按钮左右收窄以免超出表盘。
- 原有空白仓位自动按杠杆和保证金计算、复制粘贴等逻辑未更改。

GitHub Actions 编译（推荐适合手机上传方式）：
1. 建新仓库或使用现有仓库，先上传本文件同级的 ZIP：
   Watch8_BinanceRisk_Compact_v2_OneUpload.zip
   （上传 ZIP 本身，无需解压。）
2. 在仓库中新建文件 .github/workflows/build-apk.yml
   将随本次答复提供的 build-apk.yml 完整复制进去并提交。
3. GitHub Actions → Build Watch8 Binance Risk Compact v2 APK → Run workflow
4. 编译结束后下载 Watch8-BinanceRisk-Compact-v2-APK，解压得到 app-debug.apk。
5. 使用 Wear Installer 2 / ADB 安装到 Galaxy Watch8。

另一种方式：解压源码 ZIP 并将其中的 app、tests、gradle 等文件和 .github 目录上传到仓库根目录，GitHub Actions 也支持直接编译。

安装说明：
- APK 由独立 GitHub Actions 的 debug 签名生成，如与现有手表旧版签名不一致，系统可能拒绝直接覆盖安装。
- 若必须卸载旧版才能安装新版，旧版手表本地 SharedPreferences 数据可能丢失，请先记录原有输入数据。

软件不联网、不调用币安接口、不下单、无需 API key，仅是 USDT 本位线性合约的风险测算工具。
交易前仍需核对手续费、交易对价格步长、强平、滑点和资金费。
